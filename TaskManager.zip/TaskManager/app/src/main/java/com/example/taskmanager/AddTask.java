package com.example.taskmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

public class AddTask extends AppCompatActivity implements View.OnClickListener {
    boolean priorityTask = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        Spinner MonthSpinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> monthAdapter = ArrayAdapter.createFromResource(this,
                R.array.Month, android.R.layout.simple_spinner_item);
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MonthSpinner.setAdapter(monthAdapter);

        Spinner DaySpinner = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(this,
                R.array.Day, android.R.layout.simple_spinner_dropdown_item);
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        DaySpinner.setAdapter(dayAdapter);

        Spinner YearSpinner = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<CharSequence> yearAdapter = ArrayAdapter.createFromResource(this,
                R.array.Year, android.R.layout.simple_spinner_dropdown_item);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        YearSpinner.setAdapter(yearAdapter);

        Spinner HourSpinner = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<CharSequence> hourAdapter = ArrayAdapter.createFromResource(this,
                R.array.Hour, android.R.layout.simple_spinner_dropdown_item);
        hourAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        HourSpinner.setAdapter(hourAdapter);

        Spinner MinuteSpinner = (Spinner) findViewById(R.id.spinner5);
        ArrayAdapter<CharSequence> minuteAdapter = ArrayAdapter.createFromResource(this,
                R.array.Minute, android.R.layout.simple_spinner_dropdown_item);
        minuteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        MinuteSpinner.setAdapter(minuteAdapter);

        Spinner AMPMSpinner = (Spinner) findViewById(R.id.spinner6);
        ArrayAdapter<CharSequence> ampmAdapter = ArrayAdapter.createFromResource(this,
                R.array.AMPM, android.R.layout.simple_spinner_dropdown_item);
        ampmAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        AMPMSpinner.setAdapter(ampmAdapter);

      Button assign = findViewById(R.id.assign);
      assign.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.assign:
                openAssignTask();
                break;
        }
    }
    public void openAssignTask() {
        Intent intent = new Intent(this, MainActivity.class);
        // WHAT HAPPENS WITH TASK INFO GO HERE

        EditText taskName = findViewById(R.id.Task);
        String taskNameString = taskName.getText().toString();

        EditText nameName = findViewById(R.id.Name);
        String nameNameString = nameName.getText().toString();

        Switch priority = findViewById(R.id.prioritySwitch);
        priority.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    priorityTask = true;
                } else {
                    priorityTask = false;
                }
            }
        });

        Spinner MonthSpinner = (Spinner) findViewById(R.id.spinner1);
        String month = MonthSpinner.getSelectedItem().toString();

        Spinner DaySpinner = (Spinner) findViewById(R.id.spinner2);
        String day = DaySpinner.getSelectedItem().toString();

        Spinner YearSpinner = (Spinner) findViewById(R.id.spinner3);
        String year = YearSpinner.getSelectedItem().toString();

        Spinner HourSpinner = (Spinner) findViewById(R.id.spinner4);
        String hour = HourSpinner.getSelectedItem().toString();

        Spinner MinuteSpinner = (Spinner) findViewById(R.id.spinner5);
        String minute = MinuteSpinner.getSelectedItem().toString();

        Spinner AMPMSpinner = (Spinner) findViewById(R.id.spinner6);
        String ampm = AMPMSpinner.getSelectedItem().toString();

        // Where to store this information?



        startActivity(intent);

    }

}
