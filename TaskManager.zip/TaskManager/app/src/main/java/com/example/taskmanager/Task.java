package com.example.taskmanager;

public class Task {
    String taskName;
    String personName;
    boolean priority;
    int month;
    int day;
    int year;
    int hour;
    int minute;
    boolean ampm;

    public void Task () {

    }

}
