package com.example.taskmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button add = findViewById(R.id.add);
        Button edit = findViewById(R.id.edit);
        Button view = findViewById(R.id.view);
        Button report = findViewById(R.id.report);
        Button settings = findViewById(R.id.settings);

        add.setOnClickListener(this);
        edit.setOnClickListener(this);
        view.setOnClickListener(this);
        report.setOnClickListener(this);
        settings.setOnClickListener(this);



    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add:
                Toast.makeText( this,   "add clicked", Toast.LENGTH_SHORT).show();
                openAddTask();
                break;
            case R.id.edit:
                Toast.makeText( this,   "edit clicked", Toast.LENGTH_SHORT).show();
                openEditTask();
                break;
            case R.id.view:
                Toast.makeText( this,   "view clicked", Toast.LENGTH_SHORT).show();
                openViewTasks();
                break;
            case R.id.report:
                Toast.makeText( this,   "report clicked", Toast.LENGTH_SHORT).show();
                openReport();
                break;
            case R.id.settings:
                Toast.makeText( this,   "settings clicked", Toast.LENGTH_SHORT).show();
                openSettings();
                break;

        }
    }

    public void openAddTask() {
        Intent intent = new Intent(this, AddTask.class);
        startActivity(intent);
    }

    public void openEditTask() {
        Intent intent = new Intent(this, EditTask.class );
        startActivity(intent);
    }

    public void openViewTasks() {
        Intent intent = new Intent(this, EditTask.class );
        startActivity(intent);
    }

    public void openReport() {
        Intent intent = new Intent(this, EditTask.class );
        startActivity(intent);
    }

    public void openSettings() {
        Intent intent = new Intent(this, EditTask.class );
        startActivity(intent);
    }
}
